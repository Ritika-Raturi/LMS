package com.loanmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.loanmanagement.model.LoanDocuments;

@Repository
public interface LoanDocumentsRepository extends JpaRepository<LoanDocuments, Integer>{

}
