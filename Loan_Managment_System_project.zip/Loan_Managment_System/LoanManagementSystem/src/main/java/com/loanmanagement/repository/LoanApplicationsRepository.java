package com.loanmanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.loanmanagement.model.LoanApplications;

@Repository
public interface LoanApplicationsRepository extends JpaRepository<LoanApplications, Integer> {
	List<LoanApplications> findByApplicationStatus(String status);
	LoanApplications getByApplicantId(int applicantId);
	@Query("select count(a) from LoanApplications a where a.applicantId=:applicantId")
	int countByApplicantId(int applicantId);
	List<LoanApplications> findByApplicantPAN(String applicantPAN);
}
