package com.loanmanagement.service;

import java.util.List;

import com.loanmanagement.model.LoanDocuments;

public interface LoanDocumentsInterface {

	List<LoanDocuments> viewLoanDocuments();

}
