package com.loanmanagement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="loanDocuments")
public class LoanDocuments {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String documentURL;
	@ManyToOne
	@JoinColumn(name="documentTypeId", nullable=false)
	private DocumentTypes documentType;
	@ManyToOne
	@JoinColumn(name="loanApplicationId", nullable=false)
	private LoanApplications loanApplication;
}
