package com.loanmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loanmanagement.model.LoanDocuments;
import com.loanmanagement.repository.LoanDocumentsRepository;

@Service
public class LoanDocumentsService implements LoanDocumentsInterface{
	@Autowired
	LoanDocumentsRepository repo;
	
	public List<LoanDocuments> viewLoanDocuments(){
		return repo.findAll();
	}
	
	

}
