package com.loanmanagement.exception;

@SuppressWarnings("serial")
public class MaximumRequestLimitReachedException extends Exception {
	
	public MaximumRequestLimitReachedException(String message) {
		super(message);
	}

}
