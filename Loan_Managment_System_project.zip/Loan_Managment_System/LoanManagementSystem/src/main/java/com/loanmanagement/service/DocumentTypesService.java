package com.loanmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loanmanagement.model.*;
import com.loanmanagement.repository.DocumentTypesRepository;
@Service
public class DocumentTypesService implements DocumentTypesInterface {
	@Autowired
	DocumentTypesRepository repo;
	
	//Get all document types list
	public List<DocumentTypes> viewAllApplications(){
		return repo.findAll();
	}
	
	

}
