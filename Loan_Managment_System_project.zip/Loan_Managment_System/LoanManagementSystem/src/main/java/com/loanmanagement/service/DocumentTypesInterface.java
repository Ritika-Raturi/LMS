package com.loanmanagement.service;

import java.util.List;

import com.loanmanagement.model.DocumentTypes;

public interface DocumentTypesInterface {
	
	//Get all document types list
	public List<DocumentTypes> viewAllApplications();
	
}
