package com.loanmanagement.controller;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.loanmanagement.exception.MaximumRequestLimitReachedException;
import com.loanmanagement.model.LoanApplications;
import com.loanmanagement.service.LoanApplicationsInterface;


@RestController
@RequestMapping("/api")
public class LoanApplicationsController {
	
	Logger logger = LoggerFactory.getLogger(LoanApplicationsController.class);
	
	@Autowired
	LoanApplicationsInterface interfaceObj;
	
	//View all loan applications
	@CrossOrigin("http://localhost:4200")
	@GetMapping("/viewloanapplications")
	public ResponseEntity<List<LoanApplications>> viewLoanApplications(){
		logger.info("getting all values");
		try{
			return new ResponseEntity<>(interfaceObj.viewLoanApplications(),HttpStatus.OK);
		}catch(Exception e) {
			logger.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	//Get loan application by id
	@CrossOrigin("http://localhost:4200")
	@GetMapping("/loanapplications/{applicationid}")
	public ResponseEntity<Optional<LoanApplications>> getApplication(@PathVariable int applicationid) {
		try{
			logger.info("Fetching loan application details by id...");
			return new ResponseEntity<>(interfaceObj.getApplication(applicationid),HttpStatus.FOUND);
		}catch(Exception e) {
			logger.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	
	//Create loan application
	@CrossOrigin("http://localhost:4200")
	@PostMapping("/add")
	public ResponseEntity<?> addLoanApplication(@RequestBody LoanApplications loan) throws Exception {
		try{
			logger.info("Applying for a new loan...");
//			interfaceObj.addLoanApplication(loan);
			return new ResponseEntity<>(interfaceObj.addLoanApplication(loan), HttpStatus.CREATED);
		} catch(MaximumRequestLimitReachedException e) {
			logger.warn(e.getMessage());
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		} catch(Exception e) {
			logger.error(e.getMessage());
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}
	
	@CrossOrigin("http://localhost:4200")
    @PostMapping("/additionalLoanApplications")
    public ResponseEntity<String> createAdditionalLoanApplication(@RequestBody LoanApplications loanApplication) {
    	try{
    		interfaceObj.createAdditionalLoanApplication(loanApplication);
    		return ResponseEntity.ok("Additional loan application created successfully.");
    	}catch(Exception e) {
    		logger.error(e.getMessage());
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
    	}
        
    }
	
    
	//delete from loan applications
	@CrossOrigin("http://localhost:4200")
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> deleteLoan(@PathVariable int id) {
		try{
			interfaceObj.deleteLoan(id);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch(Exception e) {
			logger.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	
	//Get all new loan applications
	@GetMapping("/loanapplications/status/{status}")
	public ResponseEntity<List<LoanApplications>> newLoanApplications(@PathVariable String status) {
		try{
			return new ResponseEntity<>(interfaceObj.newLoanApplications(status),HttpStatus.FOUND);
		}catch(Exception e) {
			logger.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	
	//Respond to loan application
	@CrossOrigin("http://localhost:4200")
	@PutMapping("/update/{applicantId}")
	public ResponseEntity<LoanApplications> respond(@PathVariable int applicantId, @RequestBody LoanApplications data) {
		System.out.println("update");
		logger.info("get updated values");
		try{
			return new ResponseEntity<>(interfaceObj.respond(applicantId, data),HttpStatus.OK);
		}catch(Exception e) {
			logger.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
}
