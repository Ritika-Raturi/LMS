package com.loanmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loanmanagement.exception.MaximumRequestLimitReachedException;
import com.loanmanagement.model.LoanApplications;
import com.loanmanagement.repository.LoanApplicationsRepository;

@Service
public class LoanApplicationsService implements LoanApplicationsInterface {
	@Autowired
	LoanApplicationsRepository obj;
	
	//Get loan application by id
	public Optional<LoanApplications> getApplication(int applicationid) {
		Optional<LoanApplications> loan = obj.findById(applicationid);
		return loan;
	}

	//Create loan application
	public LoanApplications addLoanApplication(LoanApplications loan) throws MaximumRequestLimitReachedException {
		// Check if the customer already has 2 applications
		List<LoanApplications> existingApplications = obj.findByApplicantPAN(loan.getApplicantPAN());
        if (existingApplications.size() >= 2) {
            throw new MaximumRequestLimitReachedException("Maximum of 2 loan applications allowed per customer.");
        }
		
        for (LoanApplications existingApplication : existingApplications) {
            if (existingApplication.getLoanPlanId() == loan.getLoanPlanId()) {
                throw new MaximumRequestLimitReachedException("Cannot create more than 1 application for the same loan plan.");
            }
        }
        

		
        // Create the loan application
        obj.save(loan);
        return loan;
    }
	
	 public void createAdditionalLoanApplication(LoanApplications loanApplication) {
	        // Create additional loan application without limit check
	        obj.save(loanApplication);
	    }

	
	//view all loan applications
	public List<LoanApplications> viewLoanApplications(){
		return obj.findAll();
	}
	
	//delete from loan applications
	public void deleteLoan(int id) {
		obj.deleteById(id); 
	}
	
	//Get all new loan applications
	public List<LoanApplications> newLoanApplications(String status){
		return obj.findByApplicationStatus(status);
	}
	
	//Respond to loan application
		public LoanApplications respond(int applicantId, LoanApplications data) {		
			LoanApplications object = obj.getByApplicantId(applicantId);
			if (object == null)
				return null;
			object.setApplicationStatus(data.getApplicationStatus());
			obj.save(object);
			return object;
		}

}
