package com.loanmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.loanmanagement.model.LoanApplications;

@Service
public interface LoanApplicationsInterface {
	//Create loan application
	public LoanApplications addLoanApplication(LoanApplications loan) throws Exception;
	
	//Get loan application by id
	public Optional<LoanApplications> getApplication(int applicationid);

	//view all loan applications
	public List<LoanApplications> viewLoanApplications();

	//delete from loan applications
	public void deleteLoan(int id);
	
	//Get all new loan applications
	public List<LoanApplications> newLoanApplications(String status);

	//Respond to loan application
	public LoanApplications respond(int applicantId, LoanApplications data);

	public void createAdditionalLoanApplication(LoanApplications loanApplication);

}
