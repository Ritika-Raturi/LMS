package com.loanmanagement.model;

import java.time.LocalDate;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="loanApplications")
public class LoanApplications {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int applicantId;
	@Size(min=10,message="ApplicantName must be minimum 10 characters long")
	private String applicantName;
	private String applicantAddress;
	private String applicantProfession;
	@Column(length=10)
	@Size(max=10,min=10,message="User phone number should be 10 digits only")
	private String applicantPhone;
	private String applicantEmail;
	private String applicantPAN;
	private int monthlyIncome;
	@PositiveOrZero
	private int noOfDependents;
	private LocalDate applicationDate;
	private int loanPlanId;
	@Pattern(regexp="New|Approved|Rejected")
	private String applicationStatus;
	private LocalDate applicationReviewedOn;


}
