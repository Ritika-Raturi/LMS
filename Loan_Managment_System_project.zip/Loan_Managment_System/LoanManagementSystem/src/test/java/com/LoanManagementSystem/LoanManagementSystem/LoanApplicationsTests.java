package com.LoanManagementSystem.LoanManagementSystem;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.loanmanagement.exception.MaximumRequestLimitReachedException;
import com.loanmanagement.model.LoanApplications;
import com.loanmanagement.repository.LoanApplicationsRepository;
import com.loanmanagement.service.LoanApplicationsService;


public class LoanApplicationsTests {
	@Mock
	LoanApplicationsRepository loanRepo;
	
	@InjectMocks
	LoanApplicationsService loanService;
	
	LoanApplications loan = new LoanApplications();
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
		
		loan.setApplicantId(10);
		loan.setApplicantAddress("ddn");
		loan.setApplicantEmail("ueyu9ef@ufh");
		loan.setApplicantName("Riya");
		loan.setApplicantPAN("OEYUUHF");
		loan.setApplicantPhone("9795643298");
		loan.setApplicantProfession("choreographer");
		loan.setApplicationDate(LocalDate.of(2024, 01, 01));
		loan.setApplicationReviewedOn(LocalDate.of(2024, 02, 17));
		loan.setApplicationStatus("New");
		loan.setLoanPlanId(102);
		loan.setMonthlyIncome(25000);
		loan.setNoOfDependents(4);
	}
	
	@Test
	public void testAddLoanApplication() throws MaximumRequestLimitReachedException {
		
		when(loanRepo.save(any(LoanApplications.class))).thenReturn(loan);
		
		assertNotNull(loanService.addLoanApplication(loan));
		
		verify(loanRepo, times(1)).save(loan);
		
	}
	
    @Test
    public void testNewLoanApplications() {
        // Arrange
        String status = "NEW"; // Set the desired status
        List<LoanApplications> mockApplications = new ArrayList<>();
        // Add some mock LoanApplications to the list (you can customize this)

        when(loanRepo.findByApplicationStatus(status)).thenReturn(mockApplications);

        // Act
        List<LoanApplications> result = loanService.newLoanApplications(status);

         assertEquals(mockApplications.size(), result.size());
         assertTrue(result.containsAll(mockApplications));

        verify(loanRepo, times(1)).findByApplicationStatus(status);
    }
    
    @Test
    public void testGetApplication() {
        // Arrange
        int validApplicationId = 123;
        when(loanRepo.findById(validApplicationId)).thenReturn(Optional.of(loan));

        // Act
        Optional<LoanApplications> actualApplication = loanService.getApplication(validApplicationId);

        // Assert
        assertTrue(actualApplication.isPresent());
        assertEquals(loan, actualApplication.get());
    }
    
    @Test
    public void testRespond() {
        // Arrange
        int applicantId = 123;
        LoanApplications existingApplication = new LoanApplications();
        existingApplication.setApplicationStatus("PENDING");

        LoanApplications newData = new LoanApplications();
        newData.setApplicationStatus("APPROVED");

        when(loanRepo.getByApplicantId(applicantId)).thenReturn(existingApplication);

        // Act
        loanService.respond(applicantId, newData);

        // Assert
        verify(loanRepo).save(existingApplication);
        assertEquals("APPROVED", existingApplication.getApplicationStatus());
    }

}
