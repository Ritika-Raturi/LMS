package com.LoanManagementSystem.LoanManagementSystem;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.loanmanagement.model.DocumentTypes;
import com.loanmanagement.model.LoanApplications;
import com.loanmanagement.model.LoanDocuments;
import com.loanmanagement.repository.DocumentTypesRepository;
import com.loanmanagement.repository.LoanApplicationsRepository;
import com.loanmanagement.repository.LoanDocumentsRepository;
import com.loanmanagement.service.LoanDocumentsService;

public class LoanDocumentsTest {
	@Mock
	LoanDocumentsRepository repo;
	
	@Mock
	DocumentTypesRepository docRepo;
	
	@Mock
	LoanApplicationsRepository loanRepo;
	
	@InjectMocks
	LoanDocumentsService service;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	public void testviewLoanDocuments() {
		LoanDocuments obj = new LoanDocuments();
		obj.setId(1);
		obj.setDocumentURL("url");
//		DocumentTypes doc = docRepo.findById(1).get();
		DocumentTypes doc = new DocumentTypes(1, "Type1");		
		obj.setDocumentType(doc);
		LoanApplications loan = new LoanApplications();
//		LoanApplications loan = new LoanApplications(1,"Riya Raturi","DDN","Dancer","9719409692","riya@gmail.com","8736UYJ",80000,4,(Date)"2000-04-15T18:30:00.000+00:00",100,"New","2022-03-11T18:30:00.000+00:00");
		obj.setLoanApplication(loan);
		List<LoanDocuments> list= Arrays.asList(obj);
		
		when(repo.findAll()).thenReturn(list);
		
		List<LoanDocuments> list2 = service.viewLoanDocuments();
		
		assertEquals(list, list2);
		
	}

}
