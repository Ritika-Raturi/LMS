package com.LoanManagementSystem.LoanManagementSystem;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanManagementSystemApplicationTests {

}