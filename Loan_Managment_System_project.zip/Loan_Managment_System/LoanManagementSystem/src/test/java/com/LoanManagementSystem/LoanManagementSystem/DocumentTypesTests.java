package com.LoanManagementSystem.LoanManagementSystem;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.loanmanagement.model.DocumentTypes;
import com.loanmanagement.repository.DocumentTypesRepository;
import com.loanmanagement.service.DocumentTypesService;

public class DocumentTypesTests {
	@Mock
	DocumentTypesRepository repo;
	
	@InjectMocks
	DocumentTypesService service;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	public void testviewAllApplications() {
		DocumentTypes obj = new DocumentTypes(1, "Passport");
//		obj.setId(1);
//		obj.setDocumentType("passport");
		DocumentTypes obj2 = new DocumentTypes(2, "Passport");
//		obj2.setId(2);
//		obj2.setDocumentType("passport");
		List<DocumentTypes> list= Arrays.asList(obj,obj2);
		
		when(repo.findAll()).thenReturn(list);
		
		List<DocumentTypes> list2 = service.viewAllApplications();
		
		assertEquals(list, list2);
		
	}
													
}
